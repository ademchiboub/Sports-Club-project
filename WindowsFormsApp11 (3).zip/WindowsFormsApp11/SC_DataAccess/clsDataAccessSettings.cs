﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsClub_DataAccess
{
    static class clsDataAccessSettings
    {
        public static string ConnectionString = "Server=.;Database=SportsClubDB;User Id=sa;Password=123456;";
    }
}
